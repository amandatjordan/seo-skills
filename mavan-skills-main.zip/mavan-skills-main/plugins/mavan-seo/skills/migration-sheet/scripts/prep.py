#!/usr/bin/env python3
"""Normalize the old-site crawl exports, the backlink export and the Search Console sheet, and classify every internal link.
(The crawl and link parts are copied from the IA audit's prep.py: each skill in this repo is self-contained.)

Usage:
  python prep.py --domain example.com --urls URLS.csv --links LINKS.csv [--redirects REDIRECTS.csv]
                 [--backlinks BACKLINKS.csv] [--gsc GSC.xlsx] [--out work]
                 [--nav-regex R] [--footer-regex R] [--breadcrumb-regex R]

Writes to --out:
  crawl_pages.csv   one row per crawled URL (all statuses)
  links.csv         one row per linking page + target page + link class (Nav/Footer/Breadcrumb/Body)
  redirects.csv     source key -> final key for every redirect the crawl found
  backlinks.csv     key, links, is_media   every URL of this domain that has backlinks (from the backlink export)
  gsc_pages.csv     key, impressions        every page in the Search Console sheet (tab "Claude Use This" when it exists)
  prep_report.json  counts used by the README

Links are classed from the CSS path (Sitebulb) or link path / XPath (Screaming Frog), not from
the crawler's location label, which Sitebulb sets to "Navigation" for almost everything. The
label is used only when a link has no path. Run once, read the class counts and the pattern
table, and re-run with the regex options if a menu or footer is being missed.
"""
import argparse
import collections
import os
import re
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import bare_domain, is_media, key, read_table, save_json  # noqa: E402

NAV_RE = (r'(?:^|[^a-z])(?:nav|navbar|navigation|menu|mega-?menu|menu-item|sub-menu|accordion|'
          r'site-header|main-header|header-menu|masthead|off-?canvas|top-?bar|hamburger|mobile-menu)(?:[^a-z]|$)'
          r'|(?:^|[\s>/])header(?:[\s>.#\[:/]|$)|#header')
FOOTER_RE = r'footer|colophon'
BREADCRUMB_RE = r'breadcrumb'


def find(df, *names):
    """First column whose name matches one of names (case-insensitive)."""
    low = {c.lower().strip(): c for c in df.columns}
    for n in names:
        if n.lower() in low:
            return low[n.lower()]
    return None


def col(df, *names, default=''):
    c = find(df, *names)
    return df[c] if c else pd.Series([default] * len(df), index=df.index)


def read(path, **kw):
    return pd.read_csv(path, encoding='utf-8-sig', low_memory=False, dtype=str, **kw)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--domain', required=True)
    ap.add_argument('--urls', required=True)
    ap.add_argument('--links', required=True)
    ap.add_argument('--redirects')
    ap.add_argument('--client-redirects', help='optional existing redirect list (source, target columns)')
    ap.add_argument('--backlinks', help='Ahrefs or Semrush backlinks export (target URL column)')
    ap.add_argument('--gsc', help='Search Console sheet (.xlsx) with Page and Impressions columns')
    ap.add_argument('--out', default='work')
    ap.add_argument('--nav-regex', default=NAV_RE)
    ap.add_argument('--footer-regex', default=FOOTER_RE)
    ap.add_argument('--breadcrumb-regex', default=BREADCRUMB_RE)
    a = ap.parse_args()
    dom = bare_domain(a.domain)
    os.makedirs(a.out, exist_ok=True)
    report = {'domain': dom, 'warnings': []}

    # ---------- URL export ----------
    u = read(a.urls)
    if find(u, 'Address'):
        crawler = 'Screaming Frog'
    elif find(u, 'URL'):
        crawler = 'Sitebulb'
    else:
        sys.exit(f'Unrecognised URL export columns: {list(u.columns)[:20]}')
    report['crawler'] = crawler
    raw = col(u, 'Address', 'URL')
    status = pd.to_numeric(col(u, 'Status Code', 'HTTP Status Code'), errors='coerce')
    idx_text = col(u, 'Indexability Status', 'Indexable Status', 'Indexability').fillna('')
    idx_flag = col(u, 'Indexability', 'Indexable', 'Indexable Status').fillna('')
    indexable = idx_flag.str.strip().str.lower().isin(['indexable', 'yes', 'true'])
    depth_raw = col(u, 'Crawl Depth').fillna('')
    pages = pd.DataFrame({
        'url': raw,
        'key': raw.map(lambda x: key(x, dom)),
        'has_query': raw.fillna('').str.contains(r'\?', regex=True),
        'status': status,
        'indexable': indexable.map({True: 'Indexable', False: ''}),
        'index_detail': idx_text,
        'crawl_depth': depth_raw,
        'title': col(u, 'Title 1', 'Title').fillna(''),
        'h1': col(u, 'H1-1', 'H1').fillna(''),
        'h2': col(u, 'H2-1', 'H2s', 'H2', 'H2-1 (First)').fillna(''),
        'words': pd.to_numeric(col(u, 'Word Count', 'No. Content Words', 'Content Word Count'), errors='coerce'),
        'crawl_source': col(u, 'Crawl Source', 'Source').fillna(''),
        'redirect_to': col(u, 'Redirect URL', 'Redirect URL 1', 'Redirects To', 'Redirect Destination').fillna(''),
    })
    # indexability text for non-indexable pages: say why (Canonicalized, Noindex, ...)
    pages.loc[pages.indexable == '', 'indexable'] = pages.index_detail.where(pages.index_detail.str.strip() != '', 'Not indexable')
    pages = pages[pages.key != ''].drop(columns=['index_detail'])
    pages['h2'] = pages.h2.str.split(r'\s*[|\n]\s*').str[0].fillna('')
    pages = pages.sort_values(['has_query', 'status']).reset_index(drop=True)
    pages.to_csv(os.path.join(a.out, 'crawl_pages.csv'), index=False)
    counts = pages.status.fillna(0).astype(int).map(
        lambda s: '200' if s == 200 else '3xx' if 300 <= s < 400 else '4xx' if 400 <= s < 500 else '5xx' if s >= 500 else 'no response').value_counts().to_dict()
    report['url_counts'] = counts
    report['urls_total'] = int(len(pages))

    # ---------- redirects ----------
    redir = {}
    for _, r in pages[(pages.status >= 300) & (pages.status < 400) & (pages.redirect_to != '')].iterrows():
        redir[r.key] = (int(r.status), key(r.redirect_to, dom))
    if a.redirects:
        rd = read(a.redirects)
        src = col(rd, 'Address', 'Source URL', 'Source', 'URL')
        st = pd.to_numeric(col(rd, 'Status Code', 'HTTP Status Code', 'Status'), errors='coerce')
        dst = col(rd, 'Final Address', 'Redirect URL', 'Redirect Destination', 'Destination URL',
                  'Redirects To', 'Final Destination', 'Target URL')
        for s, c, d in zip(src, st, dst):
            if isinstance(s, str) and isinstance(d, str) and d.strip():
                redir[key(s, dom)] = (int(c) if c == c else 301, key(d, dom))
    rows = [{'source': k, 'status': v[0], 'final': v[1], 'origin': 'crawl'} for k, v in redir.items()]
    if a.client_redirects:
        cr = read(a.client_redirects)
        s_col = find(cr, 'source', 'source url', 'from', 'old url', 'redirect from', 'url')
        t_col = find(cr, 'target', 'target url', 'to', 'new url', 'redirect to', 'destination')
        if s_col and t_col:
            for s, t in zip(cr[s_col], cr[t_col]):
                if isinstance(s, str) and isinstance(t, str):
                    rows.append({'source': key(s, dom), 'status': 301, 'final': key(t, dom), 'origin': 'client list'})
            report['client_redirects'] = int(len(cr))
        else:
            report['warnings'].append(f'Client redirect list: could not find source/target columns in {list(cr.columns)[:10]}')
    pd.DataFrame(rows, columns=['source', 'status', 'final', 'origin']).to_csv(os.path.join(a.out, 'redirects.csv'), index=False)
    report['redirects'] = len(rows)

    # ---------- backlinks (target URLs of this domain, files included) ----------
    if a.backlinks:
        bl = read_table(a.backlinks)
        tcol = next((c for c in bl.columns if c.strip().lower() in ('target url', 'target')), None)
        if not tcol:
            sys.exit(f'Backlink export: no Target URL column. Columns are {list(bl.columns)[:15]}.')
        tk = bl[tcol].map(lambda x: key(x, dom))
        tk = tk[tk.str.startswith('/')]
        bk = tk.value_counts().rename_axis('key').reset_index(name='links')
        bk['is_media'] = bk.key.map(is_media)
        bk.to_csv(os.path.join(a.out, 'backlinks.csv'), index=False)
        report['backlink_urls'] = int(len(bk))
        report['backlink_media'] = int(bk.is_media.sum())
    # ---------- Search Console sheet ----------
    if a.gsc:
        import pandas as _pd
        tabs = _pd.read_excel(a.gsc, sheet_name=None, dtype=str, header=None)
        name = next((n for n in tabs if n.strip().lower() == 'claude use this'), None) or next(iter(tabs))
        raw_g = tabs[name].fillna('')
        hi = next((i for i in range(min(10, len(raw_g))) if {'page', 'impressions'} <= {str(c).strip().lower() for c in raw_g.iloc[i]}), None)
        if hi is None:
            sys.exit(f'Search Console sheet: no Page and Impressions columns in tab {name!r}.')
        hdr = [str(c).strip().lower() for c in raw_g.iloc[hi]]
        g = raw_g.iloc[hi + 1:].copy()
        g.columns = hdr
        g['impressions'] = _pd.to_numeric(g['impressions'].str.replace(',', ''), errors='coerce').fillna(0)
        g['key'] = g['page'].map(lambda x: key(x, dom) if str(x).strip() else '')
        g = g[g.key.str.startswith('/')].groupby('key', as_index=False)['impressions'].sum()
        g.to_csv(os.path.join(a.out, 'gsc_pages.csv'), index=False)
        report['gsc_pages'] = int(len(g))
        report['gsc_tab'] = name

    # ---------- links ----------
    head = read(a.links, nrows=0)
    if find(head, 'Linking URL'):
        m = {'src': find(head, 'Linking URL'), 'dst': find(head, 'Target URL'), 'anchor': find(head, 'Anchor Text'),
             'pos': find(head, 'Location'), 'path': find(head, 'CSS Path'), 'img': find(head, 'Image'),
             'type': None}
    elif find(head, 'Source') and find(head, 'Destination'):
        m = {'src': find(head, 'Source'), 'dst': find(head, 'Destination'), 'anchor': find(head, 'Anchor'),
             'pos': find(head, 'Link Position'), 'path': find(head, 'Link Path'), 'img': None,
             'type': find(head, 'Type'), 'alt': find(head, 'Alt Text')}
    else:
        sys.exit(f'Unrecognised links export columns: {list(head.columns)[:20]}')
    use = [c for c in m.values() if c]
    raw_counts = collections.Counter()
    acc = {}
    n_rows = 0
    path_patterns = collections.Counter()
    for ch in read(a.links, usecols=use, chunksize=200000):
        if m.get('type'):
            ch = ch[ch[m['type']].fillna('').str.lower().isin(['hyperlink', 'ahref', ''])]
        n_rows += len(ch)
        src = ch[m['src']].map(lambda x: key(x, dom))
        dst = ch[m['dst']].map(lambda x: key(x, dom))
        anchor = ch[m['anchor']].fillna('') if m['anchor'] else pd.Series([''] * len(ch), index=ch.index)
        if m.get('alt'):
            anchor = anchor.where(anchor.str.strip() != '', ch[m['alt']].fillna(''))
        pos = ch[m['pos']].fillna('').str.lower() if m['pos'] else pd.Series([''] * len(ch), index=ch.index)
        path = ch[m['path']].fillna('').str.lower() if m['path'] else pd.Series([''] * len(ch), index=ch.index)
        img = (ch[m['img']].fillna('').str.lower().isin(['true', 'yes', '1']) if m['img']
               else anchor.str.strip().eq(''))
        cls = pd.Series('Body', index=ch.index)
        has_path = path.str.strip() != ''
        cls[~has_path & pos.str.contains('nav|header')] = 'Nav'
        cls[~has_path & pos.str.contains('footer')] = 'Footer'
        cls[~has_path & pos.str.contains('breadcrumb')] = 'Breadcrumb'
        cls[has_path & path.str.contains(a.nav_regex, regex=True)] = 'Nav'
        cls[has_path & path.str.contains(a.footer_regex, regex=True)] = 'Footer'
        cls[has_path & path.str.contains(a.breadcrumb_regex, regex=True)] = 'Breadcrumb'
        keep = src.str.startswith('/') & dst.str.startswith('/')
        pat = path.str.replace(r':nth-(child|of-type)\(\d+\)', '', regex=True).str.replace(r'\[\d+\]', '', regex=True)
        pat = pat.str.replace(r'\d+', 'N', regex=True).str[-90:]
        for s, d, c, an, im, p in zip(src[keep], dst[keep], cls[keep], anchor[keep], img[keep], pat[keep]):
            k = (s, d, c)
            raw_counts[k] += 1
            path_patterns[(c, p)] += 1
            if k not in acc:
                acc[k] = [an.strip()[:150], bool(im)]
            elif not acc[k][0] and an.strip():
                acc[k][0] = an.strip()[:150]
    L = pd.DataFrame([{'src': k[0], 'dst': k[1], 'cls': k[2], 'anchor': v[0], 'image': v[1],
                       'raw_count': raw_counts[k]} for k, v in acc.items()])
    if L.empty:
        sys.exit('No internal links found. Check --domain matches the links export.')
    L.to_csv(os.path.join(a.out, 'links.csv'), index=False)
    by_cls = L.cls.value_counts().to_dict()
    report['link_rows'] = int(n_rows)
    report['links_unique'] = int(len(L))
    report['link_classes'] = {c: int(by_cls.get(c, 0)) for c in ['Nav', 'Footer', 'Breadcrumb', 'Body']}
    nav_share = by_cls.get('Nav', 0) / len(L)
    report['nav_share'] = round(nav_share, 3)
    if nav_share >= 0.95:
        report['warnings'].append('95%+ of links classed as Nav: the classification failed. Read the pattern table and pass --nav-regex.')
    if by_cls.get('Body', 0) == 0:
        report['warnings'].append('No Body links at all: the classification failed or the export has no CSS/link paths.')
    save_json(os.path.join(a.out, 'prep_report.json'), report)

    print(f'{crawler} export: {len(pages)} URLs ({", ".join(f"{k}: {v}" for k, v in counts.items())}), '
          f'{len(redir)} redirects found by the crawl')
    print(f'Links: {n_rows} internal link rows -> {len(L)} unique linking page + target + class')
    print('Link classes (unique linking page + target page):',
          ', '.join(f'{c} {report["link_classes"][c]}' for c in report['link_classes']))
    print('\nMost common link paths per class (check menus land in Nav and article copy in Body):')
    for c in ['Nav', 'Footer', 'Breadcrumb', 'Body']:
        top = [(p, n) for (cc, p), n in path_patterns.most_common() if cc == c][:6]
        for p, n in top:
            print(f'  {c:<10} {n:>7}  ...{p}')
    for w in report['warnings']:
        print('WARNING:', w)


if __name__ == '__main__':
    main()
